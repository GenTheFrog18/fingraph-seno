# Offline demo runbook

## Prerequisites

- Docker Engine and Docker Compose v2.
- A free host HTTP port. The shared environment used `18080`, so this verification used `18081`.
- No real PSP, bank, or customer data. The demo data is synthetic.

## Start an isolated persistent stack

From the repository root:

```bash
FINGRAPH_DEMO_PORT=18081 ./scripts/stabilization-demo.sh start
```

The script creates the unique Compose project `fingraph-stabilization`, network names prefixed with that project, and separate PostgreSQL/Neo4j/ML-artifact volumes. It builds the backend/frontend images, runs migration and explicit idempotent seed, trains a signed QRIS artifact into the ML volume, and waits for the public proxy.

## Send the six signed events

```bash
FINGRAPH_DEMO_PORT=18081 ./scripts/stabilization-demo.sh events
```

The host-side runner sends six HMAC-signed events from three synthetic PSPs and writes `stabilization-demo-summary.json`. It reports accepted, idempotent, error, complete-GNN, fallback, elapsed-time, and case-ID counts. It never writes raw payer tokens to its summary.

The stable replay check is:

```bash
FINGRAPH_BASE_URL=http://127.0.0.1:18081 \
  python3 backend/scripts/run_psp_demo.py --run-id idempotency-check
FINGRAPH_BASE_URL=http://127.0.0.1:18081 \
  python3 backend/scripts/run_psp_demo.py --run-id idempotency-check
```

The first command accepts six events; the second returns six `already_seen` results with zero errors.

## Open the product

Browse to `http://127.0.0.1:18081` and log in with the local seeded analyst:

- email: `analyst@fingraph.id`
- password: `password123`

Open **Kasus lintas-PSP**. Select the case to see the participants, model provenance, evidence table, privacy statement, and Cytoscape graph. The browser evidence in this return was produced through this flow.

## Verify restart persistence

```bash
FINGRAPH_DEMO_PORT=18081 ./scripts/stabilization-demo.sh restart
curl -fsS http://127.0.0.1:18081/api/v1/health/ready
```

Expected readiness includes migration `20261110_0007`, database `ready`, and model `ready`. Log back in and confirm the same case and artifact provenance remain.

## Stop only this demo project

```bash
FINGRAPH_DEMO_PORT=18081 ./scripts/stabilization-demo.sh stop
```

This is intentionally project-scoped. Do not use `docker compose down -v` against a data-bearing deployment unless volume deletion is explicitly intended.
