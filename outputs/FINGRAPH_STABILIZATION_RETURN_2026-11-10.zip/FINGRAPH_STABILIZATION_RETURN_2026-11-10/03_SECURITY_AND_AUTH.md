# Security and authorization

## Ingestion boundary

`POST /api/v1/psp/events` is authenticated with three headers:

- `X-FG-Provider`: provider key ID, normalized to lowercase;
- `X-FG-Timestamp`: signed freshness timestamp;
- `X-FG-Signature`: HMAC-SHA256 over `timestamp + "." + raw_body` using the configured provider secret.

`PSP_EVENT_KEYS` maps provider IDs to secrets. Provider/event and provider/payment unique constraints provide database idempotency. An unchanged duplicate returns `already_seen`; a changed payload returns `409`.

The payload requires the QRIS v1 schema, `payment.succeeded`, `QRIS`, and `IDR`, and rejects extra fields. `acquirer_id` must equal the authenticated provider. HMAC is only ingestion authentication; it does not grant a PSP visibility into cases.

## Investigator boundary

Case routes use `require_central_investigator`, which requires both:

1. role `analyst` or `admin`; and
2. the user email in `CENTRAL_INVESTIGATOR_EMAILS`.

The API no longer derives case scope from `User.institution_name`. A user whose institution is `psp_a` cannot obtain case access merely by holding an analyst JWT. Public registration accepts only the merchant role, and production requires an explicit central allowlist.

The demo allowlist is `analyst@fingraph.id;admin@fingraph.id`. Production deployments must supply real provisioned identities through secret/configuration management.

## Privacy and graph output

- Stored payer tokens are never serialized in case detail/evidence responses; the field is explicitly null while `payer_link_available` remains a boolean.
- Graph payer nodes use HMAC-SHA256 of `case_id` plus issuer/scheme/token. Only an opaque alias label such as `Payer A` is returned.
- Merchant graph IDs are namespaced as `provider:merchant_ref` to avoid cross-PSP collisions.
- The graph is bounded by `QRIS_CASE_GRAPH_MAX_OBSERVATIONS` and returns truncation metadata.
- The output contains no raw payer token, payer token scheme/token value, or unkeyed payer digest.

## Audit behavior

Status transitions use `update_network_case_status` audit entries. Automatic reopen uses `reopen_network_case` with the prior status, reviewer, decision, and reason in audit metadata before resetting the active review fields.

## Production caveats

This stabilization does not claim that demo secrets are suitable for production. Production still needs a KMS/secret manager, HTTPS, rate limiting, distributed replay controls, backup/restore drills, privacy/legal review, and a security assessment. These are deployment controls, not unresolved P0 behavior in this local scope.
