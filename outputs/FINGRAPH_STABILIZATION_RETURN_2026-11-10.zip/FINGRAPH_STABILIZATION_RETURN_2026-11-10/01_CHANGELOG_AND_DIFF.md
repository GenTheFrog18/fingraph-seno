# Changelog and implementation diff

## Checkpoint `c553f40` — harden cross-PSP QRIS investigation path

### Access and data handling

- Added `CENTRAL_INVESTIGATOR_EMAILS` configuration and `require_central_investigator` in `backend/app/api/deps.py`.
- Applied central investigator authorization to case list, detail, evidence, graph, and status routes in `backend/app/api/psp_intelligence.py`.
- Removed `institution_name`-derived PSP case scoping. PSP identity is an ingestion authentication concern, not a case-visibility boundary.
- Made the ingestion payload strict (`extra="forbid"`) and fixed currency to IDR in `backend/app/schemas/intelligence.py`.
- Added production validation for a non-empty central investigator allowlist.

### Case lifecycle and temporal behavior

- Updated `backend/app/services/qris_intelligence.py` to select the newest history rows under the cap while always adding the current observation.
- UTC normalization is now applied in both the dataset parser and inference timestamp helper.
- Case payer fingerprints use keyed HMAC rather than an unkeyed digest.
- Existing open cases are matched by deterministic topology expansion, not a loose two-merchant overlap.
- A dismissed exact-fingerprint case reopens as `suspected`, clears the current review decision, preserves the previous decision in `AuditLog`, and reuses the case ID.

### Investigation graph and UI

- Replaced the counts-only case graph response with a bounded graph contract in `backend/app/api/psp_intelligence.py`.
- Graph responses contain provider-namespaced merchant nodes, payment nodes, and case-local HMAC payer-link aliases; raw payer tokens never leave the backend.
- Added edge labels and reasons for payment→merchant and payment→payer-link relationships.
- Added a real Cytoscape/Cose-Bilkent renderer to `frontend/src/app/dashboard/cases/page.tsx`.
- Updated TypeScript graph types for node/edge reasons and truncation metadata.

### Deployment and demo

- Removed fixed `container_name` values and made Compose network names configurable through `FINGRAPH_NETWORK_PREFIX`, allowing isolated projects beside a shared stack.
- Passed PSP keys, central investigator allowlist, graph cap, and temporal settings explicitly through `docker-compose.yml`.
- Added `scripts/stabilization-demo.sh` for persistent start, event send, restart, logs, and stop operations.
- Made `backend/scripts/run_psp_demo.py` emit sanitized summaries and support stable `--run-id`/`--occurred-at` replay behavior.
- Added the new settings to root and backend environment templates.

### Product surface

- Updated `README.md`, landing copy, analyst navigation, and case graph presentation around institutional cross-PSP QRIS intelligence.
- Removed old merchant/federated/cross-border/model items from the primary analyst navigation while retaining their routes for compatibility.

## Checkpoint `658ed4e` — make demo replay idempotent

The demo runner previously generated a new `occurred_at` for every invocation. A repeated run ID therefore correctly looked like a changed payload and returned conflicts. The runner now accepts `--occurred-at` and defaults to a stable demo timestamp, so repeated run IDs exercise the intended provider/event idempotency path.

## Deliberately not changed

- No new database migration was necessary; the existing QRIS intelligence migration `20261110_0007` already supplied the required tables and indexes.
- The learned GNN architecture, artifact registry, signed artifact verification, and PostgreSQL system-of-record pattern were preserved.
- The pre-existing mode-only change to `scripts/smoke-test.sh` was not staged or committed by this stabilization work.
