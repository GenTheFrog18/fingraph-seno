# Deferred work and risks

## Deferred by design

1. **Production PSP onboarding.** The repository has a practical HMAC contract and demo key map, but real PSP key provisioning, rotation, KMS integration, per-provider operational ownership, and contract certification remain.
2. **Production model calibration.** The live demo artifact is synthetic and intentionally documented as such. A production model needs approved labeled data, temporal/grouped leakage review, calibration, drift monitoring, model approval, and an explicit investigator threshold policy.
3. **High-volume replay controls.** Database uniqueness handles normal idempotency and the endpoint handles a concurrent insert conflict, but a production deployment should add distributed rate limiting, queue/backpressure, retention policy, and provider-specific replay observability.
4. **Institutional workflow expansion.** Assignment, evidence export, investigator notes, escalation, legal hold, and case collaboration are not part of this stabilization gate.
5. **Privacy/legal review.** Pseudonymization and case-local HMAC are implemented, but retention, lawful basis, cross-institution access agreements, deletion, and subject-rights policy require institutional review.
6. **Legacy surface cleanup.** Merchant, federated, cross-border, and model-lab routes remain available for compatibility and should be retired or moved behind a deliberate legacy/admin boundary after the new workflow is approved.
7. **Operational resilience.** Backups, restore drills, secret rotation, external monitoring, alerting, disaster recovery, and a security assessment remain deployment work.

## Known behavior to keep visible

- The score is an **investigative priority**, not a probability of fraud or a final enforcement decision.
- Neo4j is healthy in the verified demo, but PostgreSQL is the QRIS system of record and the QRIS case path does not depend on a Neo4j-only query.
- Graph responses are deliberately bounded. A truncated graph must be treated as an investigative preview, not proof that no additional relationships exist.
- The current candidate policy is a deterministic topology gate, not a universal fraud taxonomy.

## Acceptance conclusion

No unresolved P0 blocker was observed in the requested stabilization scope. The deferred items above do not invalidate the local implementation; they define the controls required before production ingestion of real QRIS traffic.
