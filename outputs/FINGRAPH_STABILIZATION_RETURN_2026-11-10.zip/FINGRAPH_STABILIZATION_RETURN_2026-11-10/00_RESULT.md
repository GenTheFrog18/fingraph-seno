# FinGraph stabilization result

## Decision

**ACCEPTED for the requested stabilization scope.** The required P0 access-control and dismissed-case reopen paths are implemented and verified. The persistent PostgreSQL demo, signed GNN artifact, six-event cross-PSP flow, case graph UI, restart persistence, and idempotency replay all passed.

This is an implementation/demo acceptance, not a production fraud-performance claim. The bundled model is trained on the repository's deterministic synthetic demo data and its provenance says so.

## Verified outcome

- Implementation branch: `agent/primary`.
- Checkpoint commits pushed to GitHub: `c553f40` and `658ed4e`.
- Isolated Compose project: `fingraph-stabilization`.
- Shared stack remained untouched. Its reverse proxy already owned port `18080`, so the isolated stack was exposed on `127.0.0.1:18081`.
- PostgreSQL migration head: `20261110_0007`.
- Readiness after restart: database `ready`, Neo4j `ready`, model `ready`.
- Demo artifact: `qris_graph_graphsage_20261110_124614`, SHA-256 `5d1d01a5d4c3b4177573bbf63a30570d62e6333617a94d8b2b2f8079bcaaf03f`.
- Initial run: six signed events accepted, one case opened, six complete GNN scores, zero fallbacks, zero errors.
- Case topology: three PSPs/acquirers, four provider-namespaced merchants, two issuer-scoped payer links.
- Case graph: payment, merchant, and case-local HMAC payer-link nodes with payment→merchant and payment→payer-link edges and reasons.
- Review workflow: `suspected → under_review → dismissed → suspected` after new matching evidence; reopen audit was recorded.
- Stable replay: same `run_id` and stable `occurred_at` produced six `already_seen` responses, zero errors.
- Browser acceptance: analyst login loaded the case page and rendered a live Cytoscape graph; screenshot is in `evidence/browser-cases.png`.

## Scope boundary

Legacy merchant, federated-learning, cross-border, and model-lab routes remain in the repository for compatibility. The primary investigator navigation and public landing page now present the cross-PSP QRIS intelligence product.

See the other reports for the change inventory, test commands, security contract, GNN/graph details, runbook, and deferred risks.
