# Test evidence

## Automated checks

| Area | Command or check | Result |
|---|---|---|
| Python syntax | `python3 -m compileall -q backend/app backend/scripts` | PASS |
| Backend | disposable Docker image, `pytest -q backend/tests` | PASS — 35 tests |
| Backend focused | PSP intelligence and production config tests | PASS — 6 tests |
| Frontend types | `npm run typecheck` in Node 22 container | PASS |
| Frontend lint | `npm run lint` in Node 22 container | PASS — one pre-existing warning in `src/lib/auth.ts:58` |
| Frontend unit/presentation | `npm test` | PASS — 10 tests |
| Frontend production build | Docker Compose frontend build | PASS — Next.js 16.3.3 generated all routes |
| Compose configuration | `docker compose ... config --quiet` with demo secrets | PASS |

## Persistent PostgreSQL demo

The demo was run in a separate Compose project with separate named volumes. The stack completed migration and seed, then trained a signed artifact into the persistent ML volume. The first six signed PSP events yielded:

```json
{
  "events_sent": 6,
  "accepted": 6,
  "errors": 0,
  "complete_gnn_scores": 6,
  "fallback_scores": 0,
  "case_count": 1
}
```

The live readiness response after a backend restart was:

```json
{
  "status": "ready",
  "database": "ready",
  "migration_revision": "20261110_0007",
  "neo4j": "ready",
  "model": "ready",
  "optional_components_degraded": false
}
```

After restart, the same case ID remained present with its observations and the same artifact hash. The machine-readable summaries are in `evidence/`.

## Security and lifecycle checks

- Unauthenticated case access: `401`.
- Merchant JWT case access: `403`.
- Analyst JWT with a fabricated PSP-affiliated institution: `403`.
- Public registration requesting `analyst`: `403`.
- Same provider/event and unchanged body: `already_seen`.
- Same provider/event and changed body: `409`.
- Dismissed exact-fingerprint case followed by new matching evidence: same case ID, status `suspected`, `reopen_network_case` audit.
- Repeated stable six-event run: six `already_seen`, zero errors.

## Browser acceptance

Headless Chromium logged in as `analyst@fingraph.id`, opened `/dashboard/cases`, and found one visible Cytoscape graph container with the case detail, graph privacy statement, PSP topology, evidence table, and model artifact provenance. The screenshot is included as `evidence/browser-cases.png`.
