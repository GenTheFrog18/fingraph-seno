# GNN and graph integration

## Runtime path

```text
Signed PSP event
  → strict QRIS validation + provider/event idempotency
  → PostgreSQL qris_observations
  → score_observation()
  → verified signed GraphSAGE artifact, or explicit graph-heuristic fallback
  → bounded temporal window and topology candidate
  → network_cases + case_observations
  → central investigator API and Cytoscape evidence graph
```

The existing GNN infrastructure is reused rather than replaced:

- `backend/app/ml/graph/dataset.py` canonicalizes the QRIS training schema and builds heterogeneous payment/entity graphs.
- `backend/app/ml/graph/model.py` supplies the GraphSAGE model.
- `backend/app/ml/graph/training.py` trains and signs the `qris_graph` artifact.
- `backend/app/ml/graph/inference.py` loads the latest verified artifact and scores a current observation with its temporal context.
- `backend/app/ml/registry/model_registry.py` remains the artifact registry/verification boundary.

The live artifact was trained with the repository's deterministic synthetic dataset, temporal split, heterogeneous GraphSAGE schema, and two demo epochs. Its validation/test metrics are recorded in the training output and artifact provenance; they are not production performance claims.

## Temporal contract

`QRIS_OBSERVATION_WINDOW_SECONDS` defines the lookback interval ending at the current observation's UTC-normalized `received_at`. `QRIS_GNN_MAX_NODES` caps the context. The service selects newest historical rows first, always appends the current row, and sorts the final window chronologically. The dataset parser and inference path normalize timezone-aware values to UTC before dropping timezone metadata for the database/model boundary.

## Investigative topology

The candidate detector uses provider-namespaced merchant keys and issuer/scheme/token payer keys. A case candidate requires at least three merchants, three acquirers, and two issuer-scoped payer links. The case evidence stores participants, payer-link HMAC digests, observation IDs, window bounds, and the topology policy. Scores are labeled as investigative priority, not crime probability.

## Case graph contract

`GET /api/v1/cases/{case_id}/graph` returns:

- `nodes`: payment nodes, provider-namespaced merchant nodes, and case-local HMAC payer-link nodes;
- `edges`: payment→merchant and payment→payer-link edges, each with a human-readable label and reason;
- `total_observations`, `returned_observations`, and `truncated`;
- `privacy` statement.

The UI renders this contract using Cytoscape with Cose-Bilkent layout. It is not a counts-only placeholder. The included browser screenshot shows the live rendered graph and the adjacent evidence table.

## Observed live values

- Three providers: `psp_a`, `psp_b`, `psp_c`.
- Four merchant nodes in the initial case.
- Two payer-link aliases.
- Initial graph: 11 nodes and 10 edges for five case observations.
- After the lifecycle/replay checks, the case remained bounded and the browser view showed 21 nodes and 30 edges for 15 observations.
- All six initial events and all six first replay-run events received `complete` learned-GNN status with the same artifact hash.
